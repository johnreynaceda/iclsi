@section('title', 'New Grade Level')
<x-admin-layout>
    <div class="bg-white p-5 rounded-xl">
        <livewire:admin.new-grade_level />
    </div>
</x-admin-layout>
