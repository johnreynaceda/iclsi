@section('title', 'Grade Level')
<x-admin-layout>
    <div>
        <livewire:admin.grade_level_list />
    </div>
    <x-slot name="sidebar">
        <livewire:sidebar />

    </x-slot>
</x-admin-layout>
