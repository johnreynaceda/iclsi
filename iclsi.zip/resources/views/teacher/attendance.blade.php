@section('title', 'Attendances')
<x-teacher-layout>
    <div>
        <div class="mt-5">
            <livewire:teacher.attendance-list />
        </div>
    </div>

</x-teacher-layout>
