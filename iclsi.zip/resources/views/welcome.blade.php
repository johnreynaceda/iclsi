<x-main-layout>
    <div>
        <div class="flex relative flex-wrap justify-center items-center gap-2 mx-auto mt-8">
            <x-button label="Sign In" href="{{ route('login') }}" white lg class="font-medium"
                icon="arrow-left-end-on-rectangle" />
            <x-button label="Sign Up" zinc lg class="font-medium" right-icon="pencil-square" />

        </div>
    </div>
</x-main-layout>
