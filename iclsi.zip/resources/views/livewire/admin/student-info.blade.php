<div>
    <div class="bg-white p-5 rounded-xl">
        {{ $this->table }}
    </div>
</div>
