<div>
    <div class="bg-white rounded-xl p-5">
        {{ $this->table }}
    </div>
</div>
