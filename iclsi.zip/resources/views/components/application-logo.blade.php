<img src="{{ asset('images/iclsi_logo.png') }}" {{ $attributes }} alt="">
