<div class="ml-3 py-1">
    <img src="https://api.qrserver.com/v1/create-qr-code/?size=150x150&data={{ $getRecord()->student_identification }}"
        class="h-16 w-16" alt="">
</div>
