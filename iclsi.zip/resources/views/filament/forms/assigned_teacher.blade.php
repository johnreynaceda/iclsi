<div>
    <span class="text-xl font-bold text-green-600 uppercase">T. {{ $getRecord()->teacher->user->name }}</span>
</div>
