<?php

namespace App\Livewire\Teacher;

use App\Models\Attendance;
use App\Models\Student;
use Filament\Forms\Concerns\InteractsWithForms;
use Filament\Forms\Contracts\HasForms;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Concerns\InteractsWithTable;
use Filament\Tables\Contracts\HasTable;
use Filament\Tables\Table;
use Illuminate\Contracts\View\View;
use Livewire\Component;

class AttendanceList extends Component implements HasForms, HasTable
{
    use InteractsWithTable;
    use InteractsWithForms;

    public $qr;
    public $is_time_out = false;

    public function table(Table $table): Table
    {
        return $table
            ->query(Attendance::query())
            ->columns([
                TextColumn::make('student')->searchable()->formatStateUsing(
                    fn($record) => $record->student->lastname.', '.$record->student->firstname
                )->label('STUDENT NAME'),
                TextColumn::make('time_in')->date('h:i A')->label('TIME-IN')->searchable(),
                TextColumn::make('time_out')->date('h:i A')->label('TIME-OUT')->searchable(),
                TextColumn::make('created_at')->date()->label('DATE')->searchable()
            ])
            ->filters([
                // ...
            ])
            ->actions([
                // ...
            ])
            ->bulkActions([
                // ...
            ]);
    }

  
    
    
    public function render()
    {
        return view('livewire.teacher.attendance-list',[
            'todays' => Attendance::whereDate('created_at', now())->orderByDesc('created_at')->get()->take(5),
        ]);
    }
    public function updatedQr(){
      
        $data = Student::where('student_identification', $this->qr)->first();

if ($data) {
    // Check if the student already has a "time in" for today
    $attendance = Attendance::where('student_id', $data->id)
        ->whereDate('created_at', now())
        ->whereNotNull('time_in')
        ->exists();

    if (!$attendance) {
        // Create a new attendance record
        if ($this->is_time_out) {
            Attendance::create([
                'student_id' => $data->id,
                'time_out' => now(),
            ]);
        }else{
            Attendance::create([
                'student_id' => $data->id,
                'time_in' => now(),
            ]);
        }

        
    } else {
        // Student already attended today
       $attendance = Attendance::where('student_id', $data->id)->whereDate('created_at', now())->first();
       
       if ($this->is_time_out) {
        $attendance->update([
            'time_out' => now(),
           ]);
       }else{
        dd('already attendance');
       }
    }
} else {
    // Student not found
   dd('Student not found. Please check the QR code.');
}

// Clear the QR code field
$this->qr = null;
    }
    
}
