<?php

namespace App\Livewire;

use App\Models\Attendance;
use App\Models\Parents;
use App\Models\Student;
use Livewire\Component;

class TeacherDashboard extends Component
{
    public function render()
    {
        return view('livewire.teacher-dashboard',[
            'students' => Student::where('grade_level_id', auth()->user()->teacher->grade_level_id)->get(),
            'attendances' => Attendance::whereHas('student', function($record){
                $record->where('grade_level_id', auth()->user()->teacher->grade_level_id);
            })->whereDate('created_at', now())->get(),
            
        ]);
    }
}
